package com.example.autec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
